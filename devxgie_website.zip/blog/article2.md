# Blog Article 2
Another sample blog post.